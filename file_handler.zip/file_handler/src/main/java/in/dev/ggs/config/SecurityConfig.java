package in.dev.ggs.config;

public class SecurityConfig {


}
