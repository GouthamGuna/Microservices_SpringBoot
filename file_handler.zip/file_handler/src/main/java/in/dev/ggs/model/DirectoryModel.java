package in.dev.ggs.model;

public class DirectoryModel {

    private String dataStoragePath;

    public String getDataStoragePath() {
        return dataStoragePath;
    }

    public void setDataStoragePath(String dataStoragePath) {
        this.dataStoragePath = dataStoragePath;
    }
}
