package in.dev.ggs.model;

import java.util.List;

public class DocumentStorageModel {

    private List<String> files;
    private int count;

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
