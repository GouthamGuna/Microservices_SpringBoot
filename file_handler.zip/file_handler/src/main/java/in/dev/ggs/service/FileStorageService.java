package in.dev.ggs.service;

import in.dev.ggs.model.DocumentStorageModel;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public interface FileStorageService {

    CompletableFuture<String> storeFiles(List<MultipartFile> files);

    CompletableFuture<DocumentStorageModel> fileLister(String filter);

    CompletableFuture<File> getFile(String filename);

    boolean deleteFile(String fileName);
}
