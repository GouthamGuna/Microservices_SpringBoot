package in.dev.ggs.response;

public class CommonMessage {

    private String message;

    public CommonMessage(String message) {
        this.message = message;
    }
}
